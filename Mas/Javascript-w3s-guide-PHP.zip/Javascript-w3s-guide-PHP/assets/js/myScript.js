function myFunction() {
  document.getElementById("demo").innerHTML = "Párrafo cambiado";
}