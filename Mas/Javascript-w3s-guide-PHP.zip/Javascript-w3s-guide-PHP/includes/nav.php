<!-- Nav -->
<div class="sidenav">
    <a style="color:#C7C3D6;">JAVASCRIPT</a>
    <a href="index.php">1.- Introducción</a>
    <a href="2.-where-to.php">2.- Ubicación</a>
    <a href="3.-output.php">3.- Visualización</a>
    <a href="4.-program.php">4.- Programa</a>
    <a href="5.-statements.php">5.- Declaraciones</a>
    <a href="6.-syntax.php">6.- Sintáxis</a>
    <a href="7.-comments.php">7.- Comentarios</a>
    <a href="8.-variables.php">8.- Variables</a>
    <a href="9.-Operadores.php">9.- Operadores</a>
    <a href="10.-arithmetic.php">10.- Aritmética</a>
    <a href="11.-assignment.php">11.- Asignación</a>
    <a href="12.-data-types.php">12.- Tipos de datos</a>
    <a href="13.-functions.php">13.- Funciones</a>
    <a href="14.-objects.php">14.- Objetos</a>
    <a href="15.-events.php">15.- Eventos</a>
    <a href="16.-strings.php">16.- Cadenas</a>
    <a href="17.-strings-methods.php">17.- Métodos de cadenas</a>
</div>